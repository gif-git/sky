#!bin/bash

# This script will take a backup

BUS=/home/giftson/Downloads
BUD=/home/giftson/Documents/bkp/

cd $BUD
#cp -r $BUS .
rsync -azv $BUS . >> bkp-log
mv Downloads `date -I`

