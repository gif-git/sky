#!/bin/bash

# This script will send EMAIL

txt=`cat bkp-*`

SMTPFROM=giftsonnetwork@gmail.com
SMTPTO=dgiftson@gmail.com
CCTO=solomon4usoft@gmail.com
SMTPSERVER=smtp.googlemail.com:587
SMTPUSER=giftsonnetwork
SMTPPASS=GodwithUs100%
MESSAGEBODY=`echo "$txt"`
SUBJECT="This is a FTP SERVER Backup Size email of SKYOPUS"

sendEmail -f $SMTPFROM -t $SMTPTO -cc $CCTO -u $SUBJECT -m $MESSAGEBODY -s $SMTPSERVER -xu $SMTPUSER -xp $SMTPPASS 
