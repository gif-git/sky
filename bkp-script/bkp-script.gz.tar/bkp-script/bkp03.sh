#!/bin/bash

SRCPT="/home/giftson/Downloads"
DSTPT="/home/giftson/Documents/bkp/"

SRC="Source Size: `du -sh $SRCPT`"
#DST="Backup Size: `du -shc --time *`"
DST="Backup Size: `du -shc --time $DSTPT*`"
#DST="Backup Size: `du -shc $DSTPT*`"

echo $SRC
echo "$DST"


