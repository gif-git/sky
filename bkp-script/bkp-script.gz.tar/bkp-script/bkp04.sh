#!/bin/bash

tst=`cat bkp-*`

echo "$tst"
